"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
class UserService extends Service_1.Service {
    _userDAO;
    _authTokenDAO;
    _imageDao;
    _followDAO;
    _passwordDAO;
    _followCountDAO;
    constructor(daoFactory) {
        super();
        this._userDAO = daoFactory.getUserDAO();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
        this._imageDao = daoFactory.getImageDAO();
        this._followDAO = daoFactory.getFollowDAO();
        this._passwordDAO = daoFactory.getPasswordDAO();
        this._followCountDAO = daoFactory.getFollowCountDAO();
    }
    async login(alias, password) {
        try {
            const foundPassword = await this._passwordDAO.getPassword(alias);
            if (bcryptjs_1.default.hashSync(password, foundPassword)) {
                const user = await this._userDAO.getUserInformation(alias);
                if (user === undefined) {
                    throw new Error("user not found");
                }
                const authToken = await this._authTokenDAO.generateAuthToken(alias);
                return [user, authToken];
            }
            throw new Error("Invalid alias or password");
        }
        catch (error) {
            throw error;
        }
    }
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        const aliasTaken = await this._userDAO.getUserInformation(alias);
        if (aliasTaken?.alias == alias) {
            throw new Error("alias taken");
        }
        const imageUrl = await this._imageDao.putImage(alias + "." + imageFileExtension, userImageBytes);
        this._userDAO.addUser(firstName, lastName, alias, imageUrl);
        this._passwordDAO.addPassword(alias, this.saltPassword(password));
        this._followCountDAO.setFollowCounts(alias, 0, 0);
        const token = await this._authTokenDAO.generateAuthToken(alias);
        const newUser = new tweeter_shared_1.User(firstName, lastName, alias, imageUrl);
        return [newUser.dto, token];
    }
    async logout(authToken) {
        await this._authTokenDAO.deleteAuthToken(authToken);
    }
    async getUser(authToken, alias) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return (await this._userDAO.getUserInformation(alias)) || null;
    }
    async getFollowerCount(authToken, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followCountDAO.getFollowerCount(user.alias);
    }
    async getFolloweeCount(authToken, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followCountDAO.getFolloweeCount(user.alias);
    }
    async getIsFollowerStatus(authToken, user, selectedUser) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followDAO.isFollower(user.alias, selectedUser.alias);
    }
    async follow(authToken, userToFollow, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        const isAlreadyFollower = await this._followDAO.isFollower(user.alias, userToFollow.alias);
        if (isAlreadyFollower) {
            throw new Error("is already Following");
        }
        await this._followDAO.addFollow(user.alias, userToFollow.alias);
        return await this._followCountDAO.getFollowCounts(userToFollow.alias);
    }
    async unfollow(authToken, userToUnfollow, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        this._followDAO.deleteFollow(user.alias, userToUnfollow.alias);
        await this._followCountDAO.decrementFollowerCount(user.alias);
        await this._followCountDAO.decrementFolloweeCount(userToUnfollow.alias);
        return this._followCountDAO.getFollowCounts(userToUnfollow.alias);
    }
    saltPassword(password) {
        const salt = bcryptjs_1.default.genSaltSync(10);
        const hash = bcryptjs_1.default.hashSync(password, salt);
        return hash;
    }
}
exports.UserService = UserService;
