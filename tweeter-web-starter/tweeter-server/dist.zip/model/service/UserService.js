"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const buffer_1 = require("buffer");
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
class UserService extends Service_1.Service {
    _userDAO;
    _authTokenDAO;
    _imageDao;
    _followDAO;
    constructor(daoFactory) {
        super();
        this._userDAO = daoFactory.getUserDAO();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
        this._imageDao = daoFactory.getImageDAO();
        this._followDAO = daoFactory.getFollowDAO();
    }
    async login(alias, password) {
        try {
            const user = await this._userDAO.getUserInformation(alias);
            if (password === user.password) {
                const authToken = await this._authTokenDAO.generateAuthToken(alias);
                return [user, authToken];
            }
            throw new Error("Invalid alias or password");
        }
        catch (error) {
            throw error;
        }
    }
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        const aliasTaken = await this._userDAO.getUserInformation(alias);
        if (aliasTaken.alias == alias) {
            throw new Error("alias taken");
        }
        const imageStringBase64 = buffer_1.Buffer.from(userImageBytes).toString("base64");
        const imageUrl = await this._imageDao.putImage(alias + imageFileExtension, imageStringBase64);
        this._userDAO.addUser(firstName, lastName, alias, imageUrl, password);
        const token = await this._authTokenDAO.generateAuthToken(alias);
        const newUser = new tweeter_shared_1.User(firstName, lastName, alias, imageUrl);
        return [newUser.dto, token];
    }
    async logout(authToken) {
        await this._authTokenDAO.deleteAuthToken(authToken);
    }
    async getUser(authToken, alias) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._userDAO.getUserInformation(alias);
    }
    async getFollowerCount(authToken, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followDAO.getFollowerCount(user.alias);
    }
    async getFolloweeCount(authToken, user) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followDAO.getFolloweeCount(user.alias);
    }
    async getIsFollowerStatus(authToken, user, selectedUser) {
        await this._authTokenDAO.isValidAuthToken(authToken);
        return await this._followDAO.isFollower(user.alias, selectedUser.alias);
    }
    async follow(authToken, userToFollow, user) {
        this._followDAO.addFollow(user.alias, userToFollow.alias);
        const followerCount = await this.getFollowerCount(authToken, userToFollow);
        const followeeCount = await this.getFolloweeCount(authToken, userToFollow);
        return [followerCount, followeeCount];
    }
    async unfollow(authToken, userToUnfollow, user) {
        this._followDAO.deleteFollow(user.alias, userToUnfollow.alias);
        const followerCount = await this.getFollowerCount(authToken, userToUnfollow);
        const followeeCount = await this.getFolloweeCount(authToken, userToUnfollow);
        return [followerCount, followeeCount];
    }
}
exports.UserService = UserService;
