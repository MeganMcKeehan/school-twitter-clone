"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
class FollowService extends Service_1.Service {
    _followDAO;
    _authTokenDAO;
    constructor(daoFactory) {
        super();
        this._followDAO = daoFactory.getFollowDAO();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(token);
            return this._followDAO.getFollowers(userAlias, lastItem?.alias, pageSize);
        }
        catch (error) {
            return [[], false];
        }
    }
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(token);
            return this._followDAO.getFollowees(userAlias, lastItem?.alias, pageSize);
        }
        catch (error) {
            return [[], false];
        }
    }
    async getFakeData(lastItem, pageSize, userAlias) {
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfUsers(tweeter_shared_1.User.fromDto(lastItem), pageSize, userAlias);
        const dtos = items.map((user) => user.dto);
        return [dtos, hasMore];
    }
}
exports.FollowService = FollowService;
