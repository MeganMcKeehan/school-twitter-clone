"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
class FollowService extends Service_1.Service {
    _followDAO;
    _authTokenDAO;
    _userDAO;
    constructor(daoFactory) {
        super();
        this._followDAO = daoFactory.getFollowDAO();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
        this._userDAO = daoFactory.getUserDAO();
    }
    async loadMoreFollowers(token, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(token);
            const [followerAliases, hasMore] = await this._followDAO.getFollowers(userAlias, lastItem?.alias, pageSize);
            let users = [];
            if (followerAliases !== undefined) {
                users = await this.getUserDTOs(followerAliases);
            }
            return [users, hasMore];
        }
        catch (error) {
            return [[], false];
        }
    }
    async loadMoreFollowees(token, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(token);
            const [followeeAliases, hasMore] = await this._followDAO.getFollowees(userAlias, lastItem?.alias, pageSize);
            let users = [];
            if (followeeAliases !== undefined) {
                users = await this.getUserDTOs(followeeAliases);
            }
            return [users, hasMore];
        }
        catch (error) {
            return [[], false];
        }
    }
    async getUserDTOs(aliases) {
        const users = [];
        for (const alias of aliases) {
            console.log(alias);
            const foundUser = await this._userDAO.getUserInformation(alias);
            if (foundUser) {
                users.push(foundUser);
            }
        }
        return users;
    }
    async getFakeData(lastItem, pageSize, userAlias) {
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfUsers(tweeter_shared_1.User.fromDto(lastItem), pageSize, userAlias);
        const dtos = items.map((user) => user.dto);
        return [dtos, hasMore];
    }
}
exports.FollowService = FollowService;
