"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
const client_sqs_1 = require("@aws-sdk/client-sqs");
class StatusService extends Service_1.Service {
    _authTokenDAO;
    _statusDAO;
    _followDAO;
    _feedDAO;
    sqsClient;
    constructor(daoFactory) {
        super();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
        this._statusDAO = daoFactory.getStatusDAO();
        this._followDAO = daoFactory.getFollowDAO();
        this._feedDAO = daoFactory.getFeedDAO();
        this.sqsClient = new client_sqs_1.SQSClient();
    }
    async loadMoreFeedItems(authToken, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(authToken);
            const [values, hasMore] = await this._feedDAO.getFeed(userAlias, lastItem, pageSize);
            return [values, hasMore];
        }
        catch (error) {
            return [[], false];
        }
    }
    async loadMoreStoryItems(authToken, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(authToken);
            const [values, hasMore] = await this._statusDAO.getStory(userAlias, lastItem, pageSize);
            console.log(values);
            return [values, hasMore];
        }
        catch {
            return [[], false];
        }
    }
    async postStatus(authToken, newStatus) {
        this._authTokenDAO.isValidAuthToken(authToken);
        if (!newStatus) {
            throw new Error("missing status");
        }
        const status = tweeter_shared_1.Status.fromDto(newStatus);
        await this._statusDAO.addStatus(newStatus.user.alias, status.toJson(), status.timestamp.toString());
        await this.sendPostSQSMessage(newStatus.user.alias, newStatus);
    }
    async postUpdateFeedMessages(userAlias, newStatus) {
        let hasMore = true;
        const followersAliases = [];
        let lastUser = undefined;
        while (hasMore) {
            let moreUsersAliases;
            console.log(hasMore);
            [moreUsersAliases, hasMore] = await this._followDAO.getFollowers(newStatus.user.alias, lastUser, 10);
            console.log(moreUsersAliases);
            if (moreUsersAliases.length > 0) {
                for (const userAlias of moreUsersAliases) {
                    await this.sendUpdateFeedSQSMessage(userAlias, newStatus);
                }
                followersAliases.push(...moreUsersAliases);
                lastUser = moreUsersAliases.at(-1);
                console.log(lastUser);
            }
        }
    }
    async updateFeed(alias, newStatus) {
        await this._feedDAO.updateFeed(alias, newStatus.timestamp.toString(), tweeter_shared_1.Status.fromDto(newStatus).toJson());
    }
    async sendPostSQSMessage(userAlias, statusDto) {
        const sqs_url = "https://sqs.us-east-1.amazonaws.com/337909758344/post-status-queue";
        const messageBody = JSON.stringify({
            postingUserAlias: userAlias,
            statusDto: statusDto,
        });
        await this.sendGenericSQSMessage(sqs_url, messageBody);
    }
    async sendUpdateFeedSQSMessage(userAlias, statusDto) {
        const sqs_url = "https://sqs.us-east-1.amazonaws.com/337909758344/update-feed-queue";
        const messageBody = JSON.stringify({
            userAlias: userAlias,
            statusDto: statusDto,
        });
        await this.sendGenericSQSMessage(sqs_url, messageBody);
    }
    async sendGenericSQSMessage(queueUrl, messageBody) {
        const params = {
            DelaySeconds: 10,
            MessageBody: messageBody,
            QueueUrl: queueUrl,
        };
        await this.sqsClient.send(new client_sqs_1.SendMessageCommand(params));
    }
    async getFakeData(lastItem, pageSize) {
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfStatuses(tweeter_shared_1.Status.fromDto(lastItem), pageSize);
        const dtos = items.map((status) => status.dto);
        return [dtos, hasMore];
    }
}
exports.StatusService = StatusService;
