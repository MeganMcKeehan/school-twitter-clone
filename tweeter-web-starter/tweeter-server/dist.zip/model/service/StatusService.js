"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const Service_1 = require("./Service");
class StatusService extends Service_1.Service {
    _authTokenDAO;
    _statusDAO;
    _followDAO;
    _feedDAO;
    constructor(daoFactory) {
        super();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
        this._statusDAO = daoFactory.getStatusDAO();
        this._followDAO = daoFactory.getFollowDAO();
        this._feedDAO = daoFactory.getFeedDAO();
    }
    async loadMoreFeedItems(authToken, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(authToken);
            const dataPage = await this._feedDAO.getFeed(userAlias, lastItem, pageSize);
            return [dataPage.values, dataPage.hasMorePages];
        }
        catch (error) {
            return [[], false];
        }
    }
    async loadMoreStoryItems(authToken, userAlias, pageSize, lastItem) {
        try {
            await this._authTokenDAO.isValidAuthToken(authToken);
            let thisLastItem;
            if (lastItem === null) {
                thisLastItem = undefined;
            }
            else {
                thisLastItem = lastItem;
            }
            const page = await this._statusDAO.getStory(userAlias, thisLastItem, pageSize);
            return [page.values, page.hasMorePages];
        }
        catch {
            return [[], false];
        }
    }
    async postStatus(authToken, newStatus) {
        this._authTokenDAO.isValidAuthToken(authToken);
        if (!newStatus) {
            throw new Error("missing status");
        }
        this._statusDAO.addStatus(newStatus.user.alias, tweeter_shared_1.Status.fromDto(newStatus).toJson());
        let hasMore = true;
        const followersAliases = [];
        while (hasMore) {
            let moreUsersAliases;
            [moreUsersAliases, hasMore] = await this._followDAO.getFollowers(newStatus.user.alias, undefined, 10);
            followersAliases.push(...moreUsersAliases);
        }
        for (const alias in followersAliases) {
            this.updateFeed(alias, newStatus);
        }
    }
    updateFeed(alias, newStatus) {
        this._feedDAO.updateFeed(alias, newStatus);
    }
    async getFakeData(lastItem, pageSize) {
        const [items, hasMore] = tweeter_shared_1.FakeData.instance.getPageOfStatuses(tweeter_shared_1.Status.fromDto(lastItem), pageSize);
        const dtos = items.map((status) => status.dto);
        return [dtos, hasMore];
    }
}
exports.StatusService = StatusService;
