"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthenticateService = void 0;
const aws_sdk_1 = require("aws-sdk");
class AuthenticateService extends aws_sdk_1.Service {
    _authTokenDAO;
    constructor(daoFactory) {
        super();
        this._authTokenDAO = daoFactory.getAuthTokenDAO();
    }
    async generateAuthToken(alias) {
        return await this._authTokenDAO.generateAuthToken(alias);
    }
    async isValidAuthToken(authToken) {
        const valid = await this._authTokenDAO.isValidAuthToken(authToken);
        if (valid) {
            this._authTokenDAO.updateAuthToken(authToken);
        }
        else {
            this.deleteAuthToken(authToken);
            throw new Error("invalid authToken");
        }
        return valid;
    }
    async deleteAuthToken(authToken) {
        await this._authTokenDAO.deleteAuthToken(authToken);
    }
}
exports.AuthenticateService = AuthenticateService;
