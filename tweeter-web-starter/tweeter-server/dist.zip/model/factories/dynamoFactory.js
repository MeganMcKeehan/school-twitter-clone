"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoDAOFactory = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const AuthTokenDAO_1 = require("../../daos/AuthTokenDAO");
const FeedDAO_1 = require("../../daos/FeedDAO");
const FollowDAO_1 = require("../../daos/FollowDAO");
const ImageDAO_1 = require("../../daos/ImageDAO");
const PasswordDAO_1 = require("../../daos/PasswordDAO");
const StatusDAO_1 = require("../../daos/StatusDAO");
const UserDAO_1 = require("../../daos/UserDAO");
const DaoFactory_1 = require("./DaoFactory");
class DynamoDAOFactory extends DaoFactory_1.DAOFactory {
    _userDAO;
    _followDAO;
    _authTokenDAO;
    _imageDAO;
    _statusDAO;
    _passwordDAO;
    _feedDAO;
    client;
    constructor() {
        super();
        this.client = new client_dynamodb_1.DynamoDBClient({});
    }
    getUserDAO() {
        if (!this._userDAO) {
            this._userDAO = new UserDAO_1.UserDAO(this.client);
        }
        return this._userDAO;
    }
    getFollowDAO() {
        if (!this._followDAO) {
            this._followDAO = new FollowDAO_1.FollowDAO(this.client);
        }
        return this._followDAO;
    }
    getAuthTokenDAO() {
        if (!this._authTokenDAO) {
            this._authTokenDAO = new AuthTokenDAO_1.AuthtokenDAO(this.client);
        }
        return this._authTokenDAO;
    }
    getImageDAO() {
        if (!this._imageDAO) {
            this._imageDAO = new ImageDAO_1.ImageDAO();
        }
        return this._imageDAO;
    }
    getStatusDAO() {
        if (!this._statusDAO) {
            this._statusDAO = new StatusDAO_1.StatusDAO(this.client);
        }
        return this._statusDAO;
    }
    getPasswordDAO() {
        if (!this._passwordDAO) {
            this._passwordDAO = new PasswordDAO_1.PasswordDAO(this.client);
        }
        return this._passwordDAO;
    }
    getFeedDAO() {
        if (!this._feedDAO) {
            this._feedDAO = new FeedDAO_1.FeedDAO(this.client);
        }
        return this._feedDAO;
    }
}
exports.DynamoDAOFactory = DynamoDAOFactory;
