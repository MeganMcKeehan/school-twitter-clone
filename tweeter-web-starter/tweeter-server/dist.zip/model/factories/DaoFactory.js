"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DAOFactory = void 0;
class DAOFactory {
}
exports.DAOFactory = DAOFactory;
