"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseConnection = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class databaseConnection {
    client = new client_dynamodb_1.DynamoDBClient({});
    docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(this.client);
}
exports.databaseConnection = databaseConnection;
