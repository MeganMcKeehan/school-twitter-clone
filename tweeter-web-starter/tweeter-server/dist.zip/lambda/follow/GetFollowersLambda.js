"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../model/service/FollowService");
const dynamoFactory_1 = require("../../model/factories/dynamoFactory");
const UserService_1 = require("../../model/service/UserService");
const handler = async (request) => {
    const daoFactory = new dynamoFactory_1.DynamoDAOFactory();
    const followService = new FollowService_1.FollowService(daoFactory);
    const userService = new UserService_1.UserService(daoFactory);
    const [items, hasMore] = await followService.loadMoreFollowers(request.token, request.userAlias, request.pageSize, request.lastItem);
    const users = [];
    for (const item in items) {
        const foundUser = await userService.getUser(request.token, item);
        if (foundUser) {
            users.push(foundUser);
        }
    }
    return {
        success: true,
        message: null,
        items: users,
        hasMore: hasMore,
    };
};
exports.handler = handler;
