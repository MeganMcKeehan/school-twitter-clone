"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../model/service/StatusService");
const dynamoFactory_1 = require("../../model/factories/dynamoFactory");
const handler = async (event) => {
    const statusService = new StatusService_1.StatusService(new dynamoFactory_1.DynamoDAOFactory());
    console.log(event);
    for (let i = 0; i < event.Records.length; ++i) {
        const request = JSON.parse(event.Records[i].body);
        console.log(request);
        if (request) {
            await statusService.updateFeed(request.userAlias, request.statusDto);
        }
    }
    return { success: true, message: "success" };
};
exports.handler = handler;
