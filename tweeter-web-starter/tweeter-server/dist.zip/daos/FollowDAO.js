"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class FollowDAO {
    client;
    TABLE_NAME = "follow-table";
    FOLLOWER_ALIAS = "follower_handle";
    FOLLWEE_ALIAS = "followee_handle";
    constructor(db) {
        this.client = db;
    }
    async getFollowers(alias, lastItem = undefined, limit = 10) {
        const params = {
            KeyConditionExpression: this.FOLLOWER_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": alias,
            },
            TableName: this.TABLE_NAME,
            Limit: limit,
            ExclusiveStartKey: lastItem === undefined
                ? undefined
                : {
                    [this.FOLLOWER_ALIAS]: lastItem,
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        if (data.Items) {
            data.Items?.forEach((item) => items.push(item[this.FOLLWEE_ALIAS]));
        }
        return [items, hasMorePages];
    }
    async getFollowees(alias, lastItem = undefined, limit = 10) {
        const params = {
            KeyConditionExpression: this.FOLLWEE_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": alias,
            },
            TableName: this.TABLE_NAME,
            IndexName: "follows-index",
            Limit: limit,
            ExclusiveStartKey: lastItem === undefined // this has a type error if undefined
                ? undefined
                : {
                    [this.FOLLWEE_ALIAS]: lastItem,
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        console.log(data);
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        if (data.Items) {
            data.Items?.forEach((item) => items.push(item[this.FOLLOWER_ALIAS]));
        }
        return [items, hasMorePages];
    }
    async addFollow(follower, followee) {
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                followerAlias: { S: follower },
                followeeAlias: { S: followee },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            console.log("result : " + data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async deleteFollow(user, selectedUser) {
        const params = {
            TableName: this.TABLE_NAME,
            Key: {
                follower_handle: { S: user },
                followee_handle: { S: selectedUser },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.DeleteItemCommand(params));
            console.log("result : " + data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async isFollower(user, selectedUser) {
        const params = {
            TableName: this.TABLE_NAME,
            Key: {
                followee_handle: { S: selectedUser },
                follower_handle: { S: user },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.GetItemCommand(params));
            return data ? true : false;
        }
        catch {
            return false;
        }
    }
    async getFollowerCount(userAlias) {
        const params = {
            KeyConditionExpression: this.FOLLWEE_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": userAlias,
            },
            TableName: this.TABLE_NAME,
            IndexName: "follows-index",
            Select: client_dynamodb_1.Select.COUNT,
        };
        try {
            const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
            return data.Count || 0;
        }
        catch {
            return 0;
        }
    }
    async getFolloweeCount(userAlias) {
        const params = {
            KeyConditionExpression: this.FOLLOWER_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": userAlias,
            },
            TableName: this.TABLE_NAME,
            Select: client_dynamodb_1.Select.COUNT,
        };
        try {
            const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
            return data.Count || 0;
        }
        catch {
            return 0;
        }
    }
}
exports.FollowDAO = FollowDAO;
