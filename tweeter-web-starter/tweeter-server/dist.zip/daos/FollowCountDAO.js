"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowCountDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class FollowCountDAO {
    client;
    TABLE_NAME = "follow-count-table";
    FOLLOWEE_COUNT = "followee_count";
    FOLLOWER_COUNT = "follower_count";
    constructor(db) {
        this.client = db;
    }
    async getFollowerCount(userAlias) {
        try {
            const data = await this.getFollowCountsGeneric(userAlias);
            return Number(data.Item?.follower_count?.N) || 0;
        }
        catch {
            return 0;
        }
    }
    async getFolloweeCount(userAlias) {
        try {
            const data = await this.getFollowCountsGeneric(userAlias);
            return Number(data.Item?.followee_count?.N) || 0;
        }
        catch {
            return 0;
        }
    }
    async getFollowCounts(userAlias) {
        try {
            const data = await this.getFollowCountsGeneric(userAlias);
            return [
                Number(data.Item?.follower_count?.N) || 0,
                Number(data.Item?.followee_count?.N) || 0,
            ];
        }
        catch {
            return [0, 0];
        }
    }
    async setFollowCounts(userAlias, followeeCount, followerCount) {
        const params = {
            Item: {
                user_alias: { S: userAlias },
                followee_count: { N: followeeCount.toString() },
                follower_count: { N: followerCount.toString() },
            },
            TableName: this.TABLE_NAME,
        };
        try {
            await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            return [followeeCount, followerCount];
        }
        catch {
            return [0, 0];
        }
    }
    async incrementFolloweeCount(userAlias) {
        await this.genericIncrement(userAlias, this.FOLLOWEE_COUNT, 1);
    }
    async decrementFolloweeCount(userAlias) {
        await this.genericIncrement(userAlias, this.FOLLOWEE_COUNT, -1);
    }
    async incrementFollowerCount(userAlias) {
        await this.genericIncrement(userAlias, this.FOLLOWER_COUNT, 1);
    }
    async decrementFollowerCount(userAlias) {
        await this.genericIncrement(userAlias, this.FOLLOWER_COUNT, -1);
    }
    async getFollowCountsGeneric(userAlias) {
        const params = {
            Key: { user_alias: { S: userAlias } },
            TableName: this.TABLE_NAME,
        };
        return await this.client.send(new lib_dynamodb_1.GetCommand(params));
    }
    async genericIncrement(userAlias, attributeToIncrement, incrementAmount) {
        const params = {
            TableName: this.TABLE_NAME,
            Key: { ["user_alias"]: userAlias },
            ExpressionAttributeValues: { ":inc": incrementAmount },
            UpdateExpression: "SET " +
                attributeToIncrement +
                " = " +
                attributeToIncrement +
                " + :inc",
        };
        await this.client.send(new lib_dynamodb_1.UpdateCommand(params));
    }
}
exports.FollowCountDAO = FollowCountDAO;
