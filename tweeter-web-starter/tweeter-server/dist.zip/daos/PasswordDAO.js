"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PasswordDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class PasswordDAO {
    client;
    TABLE_NAME = "password-table";
    constructor() {
        this.client = new client_dynamodb_1.DynamoDBClient({});
    }
    async getPassword(alias) {
        const params = {
            TableName: this.TABLE_NAME,
            Key: { alias: { S: alias } },
        };
        const data = await this.client.send(new client_dynamodb_1.GetItemCommand(params));
        console.log("result : ", data);
        const foundPassword = data.Item ? data.Item["password"]?.S : "";
        return foundPassword || "";
    }
    async addPassword(alias, password) {
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                alias: { S: alias },
                password: { S: password },
            },
        };
        await this.client.send(new client_dynamodb_1.PutItemCommand(params));
    }
}
exports.PasswordDAO = PasswordDAO;
