"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class StatusDAO {
    client;
    TABLE_NAME = "status-table";
    USER_ALIAS = "user_alias";
    TIMESTAMP = "timestamp";
    constructor() {
        this.client = new client_dynamodb_1.DynamoDBClient({});
    }
    async addStatus(alias, post) {
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                post: { S: post },
                user_alias: { S: alias },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            console.log("result : ", data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async getStory(alias, lastItem = null, limit = 10) {
        const params = {
            KeyConditionExpression: this.USER_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": alias,
            },
            TableName: this.TABLE_NAME,
            Limit: limit,
            ExclusiveStartKey: lastItem === null
                ? undefined
                : {
                    ["post"]: lastItem.post,
                    [this.USER_ALIAS]: lastItem.user,
                    [this.TIMESTAMP]: lastItem.timestamp.toString(),
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        data.Items?.forEach((item) => items.push(new tweeter_shared_1.Status(item["post"], item[this.USER_ALIAS], item[this.TIMESTAMP])
            .dto));
        return new tweeter_shared_1.DataPage(items, hasMorePages);
    }
    async getFeed(lastItem = null, limit = 10) {
        const params = {
            TableName: this.TABLE_NAME,
            Limit: limit,
            ExclusiveStartKey: lastItem === null
                ? undefined
                : {
                    ["post"]: lastItem.post,
                    [this.USER_ALIAS]: lastItem.user,
                    [this.TIMESTAMP]: lastItem.timestamp.toString(),
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        data.Items?.forEach((item) => items.push(new tweeter_shared_1.Status(item["post"], item[this.USER_ALIAS], item[this.TIMESTAMP])
            .dto));
        return new tweeter_shared_1.DataPage(items, hasMorePages);
    }
}
exports.StatusDAO = StatusDAO;
