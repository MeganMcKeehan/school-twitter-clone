"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class StatusDAO {
    client;
    TABLE_NAME = "status-table";
    USER_ALIAS = "user_alias";
    constructor(db) {
        this.client = db;
    }
    async addStatus(alias, post, timestamp) {
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                post: { S: post },
                user_alias: { S: alias },
                timestamp: { S: timestamp },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            console.log("result : ", data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async getStory(alias, lastItem = null, limit = 10) {
        const lastItemTimestamp = lastItem === null ? "0" : lastItem.timestamp.toString();
        const lastItemUser = lastItem === null ? "" : lastItem.user.alias;
        const params = {
            KeyConditionExpression: this.USER_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": alias,
            },
            TableName: this.TABLE_NAME,
            Limit: limit,
            ExclusiveStartKey: lastItem === null
                ? undefined
                : {
                    ["timestamp"]: lastItemTimestamp,
                    [this.USER_ALIAS]: lastItemUser,
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        console.log("data: ", data);
        if (data.Items) {
            for (const item of data.Items) {
                const post = item["post"];
                if (post != null) {
                    const status = tweeter_shared_1.Status.fromJson(post);
                    items.push(status.dto);
                }
            }
        }
        console.log("items: ", items);
        return [items, hasMorePages];
    }
}
exports.StatusDAO = StatusDAO;
