"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class UserDAO {
    client;
    TABLE_NAME = "user-table";
    constructor() {
        this.client = new client_dynamodb_1.DynamoDBClient({});
    }
    async getUserInformation(alias) {
        const params = {
            TableName: this.TABLE_NAME,
            Key: { alias: { S: alias } },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.GetItemCommand(params));
            console.log("result : ", data);
            if (data.Item &&
                data.Item["firstName"].S &&
                data.Item["lastName"].S &&
                data.Item["imageUrl"].S) {
                return new tweeter_shared_1.User(data.Item["firstName"].S, data.Item["lastName"].S, alias, data.Item["imageUrl"].S).dto;
            }
            return new tweeter_shared_1.User("", "", "", "");
        }
        catch (error) {
            console.error("Error retrieving user: ", error);
            return new tweeter_shared_1.User("", "", "", "");
        }
    }
    async addUser(firstName, lastName, alias, imageUrl) {
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                firstName: { S: firstName },
                lastName: { S: lastName },
                alias: { S: alias },
                imageUrl: { S: imageUrl },
            },
        };
        try {
            await this.client.send(new client_dynamodb_1.PutItemCommand(params));
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
}
exports.UserDAO = UserDAO;
