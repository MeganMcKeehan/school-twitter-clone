"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthtokenDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class AuthtokenDAO {
    client;
    TABLE_NAME = "authtoken-table";
    TIME_TILL_TOKEN_EXPIRATION_MS = 24 * 60 * 60 * 1000;
    constructor(db) {
        this.client = db;
    }
    async generateAuthToken(alias) {
        const newAuthToken = tweeter_shared_1.AuthToken.Generate();
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                token: { S: newAuthToken.token },
                timestamp: { S: newAuthToken.timestamp.toString() },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            return newAuthToken.token;
        }
        catch (error) {
            console.error("Error:", error);
            throw error;
        }
    }
    async isValidAuthToken(authToken) {
        let token;
        if (authToken instanceof tweeter_shared_1.AuthToken) {
            token = authToken.token;
        }
        else {
            token = authToken;
        }
        const params = {
            TableName: this.TABLE_NAME,
            Key: { token },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.GetItemCommand(params));
            if (!data.Item) {
                return false;
            }
            const timestamp = Number(data.Item["timestamp"].S);
            if (Date.now() < timestamp + this.TIME_TILL_TOKEN_EXPIRATION_MS) {
                return true;
            }
            return false;
        }
        catch (error) {
            console.error("Error:", error);
            return false;
        }
    }
    async deleteAuthToken(authToken) {
        let token;
        if (authToken instanceof tweeter_shared_1.AuthToken) {
            token = authToken.token;
        }
        else {
            token = authToken;
        }
        const params = {
            TableName: this.TABLE_NAME,
            Key: {
                followerAlias: { S: token },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.DeleteItemCommand(params));
            console.log("result : " + data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async removeExpiredTokens() {
        const params = {
            TableName: this.TABLE_NAME,
            Key: {
                followerAlias: { S: "aaaaa" },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.DeleteItemCommand(params));
            console.log("result : " + data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async updateAuthToken(authToken) {
        let token;
        if (authToken instanceof tweeter_shared_1.AuthToken) {
            token = authToken.token;
        }
        else {
            token = authToken;
        }
        const timestamp = Date.now();
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                token: { S: token },
                timestamp: { S: timestamp.toString() },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
        }
        catch (error) {
            console.error("Error:", error);
            throw error;
        }
    }
}
exports.AuthtokenDAO = AuthtokenDAO;
