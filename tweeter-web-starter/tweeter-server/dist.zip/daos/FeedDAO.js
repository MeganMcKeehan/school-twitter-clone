"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedDAO = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const tweeter_shared_1 = require("tweeter-shared");
class FeedDAO {
    client;
    TABLE_NAME = "feed-table";
    USER_ALIAS = "user_alias";
    constructor(db) {
        this.client = db;
    }
    async updateFeed(alias, timestamp, post) {
        console.log("updateFeed: " + alias + " " + timestamp + " " + post);
        const params = {
            TableName: this.TABLE_NAME,
            Item: {
                post: { S: post },
                timestamp: { S: timestamp },
                user_alias: { S: alias },
            },
        };
        try {
            const data = await this.client.send(new client_dynamodb_1.PutItemCommand(params));
            console.log("result : ", data);
        }
        catch (error) {
            console.error("Error:", error);
        }
    }
    async getFeed(alias, lastItem = null, limit = 10) {
        const params = {
            KeyConditionExpression: this.USER_ALIAS + " = :alias",
            ExpressionAttributeValues: {
                ":alias": alias,
            },
            TableName: this.TABLE_NAME,
            Limit: limit,
            ExclusiveStartKey: lastItem === null
                ? undefined
                : {
                    ["post"]: tweeter_shared_1.Status.fromDto(lastItem)?.toJson,
                    ["timestamp"]: tweeter_shared_1.Status.fromDto(lastItem)?.timestamp.toString(),
                    [this.USER_ALIAS]: lastItem.user,
                },
        };
        const items = [];
        const data = await this.client.send(new lib_dynamodb_1.QueryCommand(params));
        const hasMorePages = data.LastEvaluatedKey !== undefined;
        if (data.Items) {
            for (const item of data.Items) {
                const post = item["post"].S;
                if (post != null) {
                    const status = tweeter_shared_1.Status.fromJson(post);
                    items.push(status.dto);
                }
            }
        }
        return new tweeter_shared_1.DataPage(items, hasMorePages);
    }
}
exports.FeedDAO = FeedDAO;
